DIMU HEADSHOT PRO — Android Studio Project

මෙය Android WebView wrapper project එකකි. App එක තුළ කලින් සකස් කළ Aim Trainer එක offline ලෙස විවෘත වේ.

APK එක build කරන ආකාරය:
1. Android Studio install කර මෙම project folder එක Open කරන්න.
2. Gradle sync අවසන් වනතුරු ඉන්න.
3. Build > Build Bundle(s) / APK(s) > Build APK(s) තෝරන්න.
4. APK එක app/build/outputs/apk/debug/app-debug.apk තුළ ලැබේ.

සටහන:
- මෙහි සූදානම් APK binary එකක් ඇතුළත් නැත; මෙය APK එක build කිරීමට අවශ්‍ය source project එකයි.
- Build කිරීමට Android Studio සහ Android SDK අවශ්‍යයි.
- මෙය ස්වාධීන Aim Trainer එකකි. Free Fire වෙත සම්බන්ධ වීමක්, auto-aim හෝ auto-headshot පහසුකමක් නැත.
